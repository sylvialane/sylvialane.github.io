
public class WordAlignment {

	public final int sourceIndex;
	public final int targetIndex;
	
	public WordAlignment(int sourceIndex, int targetIndex) {
		this.sourceIndex = sourceIndex;
		this.targetIndex = targetIndex;
	}
	
}
